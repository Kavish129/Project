<?php
$con=mysqli_connect('localhost','root','','kavish');
if(!$con){
    die(mysqli_error($con));
}
?>